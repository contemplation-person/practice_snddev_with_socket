isql -s 127.0.0.1 -u SYS -p MANAGER -f EMG_CRT_USER.sql
isql -s 127.0.0.1 -u EMG -p emg123 -f EMG_CRT_SYN.sql
isql -s 127.0.0.1 -u EMG -p emg123 -f EMG_CRT_DIR.sql
isql -s 127.0.0.1 -u EMG -p emg123 -f EMG_CRT_SEQ.sql
isql -s 127.0.0.1 -u EMG -p emg123 -f EMG_CRT_TBL.sql
isql -s 127.0.0.1 -u EMG -p emg123 -f EMG_CRT_LIB.sql
isql -s 127.0.0.1 -u EMG -p emg123 -f EMG_CRT_VIEW_PROC.sql
isql -s 127.0.0.1 -u EMG -p emg123 -f EMG_CRT_LINK.sql
