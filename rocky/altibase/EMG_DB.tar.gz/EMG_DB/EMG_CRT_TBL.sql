
connect "EMG" / "emg123"

--############################
--  "EMG"."ACCOUNT_TBL"  
--############################
create table "ACCOUNT_TBL"
(
    "LTEID" VARCHAR(32) fixed not null,
    "SLICE_ID" SMALLINT default 0,
    "USERNAME" VARCHAR(24) fixed not null,
    "PASSWORD" VARCHAR(100) fixed not null,
    "CHANGE_TIME" DATE,
    "EXPIRY_TIME" DATE not null,
    "CREATE_TIME" DATE default SYSDATE,
    "UPDATE_TIME" DATE
)
 tablespace "SYS_TBS_MEM_DATA";

connect "EMG" / "emg123"

--############################
--  "EMG"."ACL_TBL"  
--############################
create table "ACL_TBL"
(
    "NAS_MDN" VARCHAR(16) fixed not null,
    "SUBUE_MAC" VARCHAR(18) fixed not null,
    "LTEID" VARCHAR(32) fixed not null,
    "SLICE_ID" SMALLINT default 0,
    "CREATE_TIME" DATE default SYSDATE,
    "UPDATE_TIME" DATE
)
 tablespace "SYS_TBS_MEM_DATA";

connect "EMG" / "emg123"

--############################
--  "EMG"."NAS_HIST_TBL"  
--############################
create table "NAS_HIST_TBL"
(
    "MDN" VARCHAR(16) not null,
    "LTEID" VARCHAR(32) not null,
    "SLICE_ID" SMALLINT not null,
    "IP_ADDR" VARCHAR(48) not null,
    "ON_DATE" DATE not null,
    "OFF_DATE" DATE not null,
    "TERM_CAUSE" VARCHAR(32) not null
)
 tablespace "HIST_TBS"
 pctfree 10
 pctused 40 
 storage ( initextents 1 nextextents 1 minextents 1 maxextents 4294967295 );

connect "EMG" / "emg123"

--############################
--  "EMG"."NAS_TBL"  
--############################
create table "NAS_TBL"
(
    "MDN" VARCHAR(16) fixed not null,
    "LTEID" VARCHAR(32) fixed not null,
    "SLICE_ID" SMALLINT default 0,
    "IMEI" VARCHAR(20) fixed,
    "SUSPEND" SMALLINT default 0,
    "SSID_1_USE" SMALLINT default 0,
    "SSID_1_NAME" VARCHAR(48) fixed,
    "SSID_1_HIDDEN" SMALLINT default 0,
    "SSID_1_WPA_PRO" SMALLINT default 0,
    "SSID_1_WPA_ENC" SMALLINT default 0,
    "SSID_2_USE" SMALLINT default 0,
    "SSID_2_NAME" VARCHAR(48) fixed,
    "SSID_2_HIDDEN" SMALLINT default 0,
    "SSID_2_WPA_PRO" SMALLINT default 0,
    "SSID_2_WPA_ENC" SMALLINT default 0,
    "UTP_1_USE" SMALLINT default 0,
    "UTP_1_AUTH_TYPE" SMALLINT default 0,
    "UTP_2_USE" SMALLINT default 0,
    "UTP_2_AUTH_TYPE" SMALLINT default 0,
    "ALIVE_CHK_MODE" SMALLINT default 0,
    "ALIVE_CHK_INT" SMALLINT default 3600,
    "MAX_SESSION" SMALLINT default 2,
    "MAX_SUBUE" SMALLINT default 2,
    "ACL_USE" SMALLINT default 0,
    "CREATE_TIME" DATE default SYSDATE,
    "UPDATE_TIME" DATE,
    "IP_ADDR" VARCHAR(48) fixed,
    "ON_DATE" DATE,
    "OFF_DATE" DATE,
    "STATUS_DATE" DATE,
    "ACCT_SESS_ID" VARCHAR(128) variable,
    "STATUS" SMALLINT default 0,
    "LAST_TERM_CAUSE" VARCHAR(32) fixed
)
 tablespace "SYS_TBS_MEM_DATA";

connect "EMG" / "emg123"

--############################
--  "EMG"."SOCINFO_TBL"  
--############################
create table "SOCINFO_TBL"
(
    "LTEID" VARCHAR(32) fixed not null,
    "SLICE_ID" SMALLINT default 0,
    "MDN" VARCHAR(16) fixed not null,
    "SUSPEND" SMALLINT default 0,
    "VLAN_ID" SMALLINT,
    "EMG_ENC_USE" SMALLINT default 1,
    "EMGU_IP" VARCHAR(48) fixed,
    "EMGU_IP6" VARCHAR(48) fixed,
    "RAD_SECRET" VARCHAR(64) fixed,
    "CREATE_TIME" DATE default SYSDATE,
    "UPDATE_TIME" DATE
)
 tablespace "SYS_TBS_MEM_DATA";

connect "EMG" / "emg123"

--############################
--  "EMG"."SUBUE_HIST_TBL"  
--############################
create table "SUBUE_HIST_TBL"
(
    "MAC" VARCHAR(18) fixed not null,
    "LTEID" VARCHAR(32) fixed not null,
    "SLICE_ID" SMALLINT not null,
    "IP_ADDR" VARCHAR(48) fixed not null,
    "USERNAME" VARCHAR(24) fixed,
    "NAS_MDN" VARCHAR(16) fixed not null,
    "NAS_IP" VARCHAR(48) fixed not null,
    "NAS_PORT_TYPE" SMALLINT not null,
    "AUTH_METHOD" SMALLINT not null,
    "SESS_START_DATE" DATE not null,
    "SESS_STOP_DATE" DATE not null,
    "TERM_CAUSE" VARCHAR(32) fixed not null,
    "IN_OCTETS" BIGINT not null,
    "OUT_OCTETS" BIGINT not null,
    "IN_GIGAWORDS" SMALLINT not null,
    "OUT_GIGAWORDS" SMALLINT not null,
    "LAST_IN_OCTETS" BIGINT not null,
    "LAST_OUT_OCTETS" BIGINT not null,
    "LAST_IN_GIGAWORDS" SMALLINT not null,
    "LAST_OUT_GIGAWORDS" SMALLINT not null
)
 tablespace "SYS_TBS_MEM_DATA";

connect "EMG" / "emg123"

--############################
--  "EMG"."SUBUE_IP6POOL_TBL"  
--############################
create table "SUBUE_IP6POOL_TBL"
(
    "LTEID" VARCHAR(32) fixed not null,
    "SLICE_ID" SMALLINT default 0,
    "IP_POOL_INDEX" INTEGER not null,
    "PREFIX" VARCHAR(48) fixed,
    "PFX_BITS" SMALLINT default 64 not null,
    "START_IP" VARCHAR(48) fixed not null,
    "END_IP" VARCHAR(48) fixed not null,
    "GATEWAY_IP" VARCHAR(48) fixed,
    "DNS_IP" VARCHAR(48) fixed,
    "UPDATE_TIME" DATE,
    "CREATE_TIME" DATE default SYSDATE,
    "IN_USE" SMALLINT
)
 tablespace "SYS_TBS_MEM_DATA";

connect "EMG" / "emg123"

--############################
--  "EMG"."SUBUE_IP6_TBL"  
--############################
create table "SUBUE_IP6_TBL"
(
    "LTEID" VARCHAR(32) fixed not null,
    "SLICE_ID" SMALLINT default 0,
    "IP_POOL_INDEX" INTEGER not null,
    "IP_ADDR" VARCHAR(48) fixed not null,
    "PREFIX" VARCHAR(48) fixed,
    "PFX_BITS" INTEGER,
    "MAC" VARCHAR(18) fixed,
    "CREATE_TIME" DATE default SYSDATE,
    "UPDATE_TIME" DATE,
    "DNS_IP" VARCHAR(48) fixed
)
 tablespace "SYS_TBS_MEM_DATA";

connect "EMG" / "emg123"

--############################
--  "EMG"."SUBUE_IPPOOL_TBL"  
--############################
create table "SUBUE_IPPOOL_TBL"
(
    "LTEID" VARCHAR(32) fixed not null,
    "SLICE_ID" SMALLINT default 0,
    "IP_POOL_INDEX" INTEGER not null,
    "SUBNET" VARCHAR(48) fixed,
    "SUBNET_MASK" VARCHAR(48) fixed default '255.255.255.0',
    "START_IP" VARCHAR(48) fixed not null,
    "END_IP" VARCHAR(48) fixed not null,
    "GATEWAY_IP" VARCHAR(48) fixed,
    "DNS_IP" VARCHAR(48) fixed,
    "CREATE_TIME" DATE default SYSDATE,
    "UPDATE_TIME" DATE,
    "IN_USE" SMALLINT
)
 tablespace "SYS_TBS_MEM_DATA";

connect "EMG" / "emg123"

--############################
--  "EMG"."SUBUE_IP_TBL"  
--############################
create table "SUBUE_IP_TBL"
(
    "LTEID" VARCHAR(32) fixed not null,
    "SLICE_ID" SMALLINT default 0,
    "IP_POOL_INDEX" INTEGER not null,
    "NETMASK" VARCHAR(48) fixed not null,
    "IP_ADDR" VARCHAR(48) fixed not null,
    "MAC" VARCHAR(18) fixed,
    "CREATE_TIME" DATE default SYSDATE,
    "UPDATE_TIME" DATE,
    "DNS_IP" VARCHAR(48) fixed
)
 tablespace "SYS_TBS_MEM_DATA";

connect "EMG" / "emg123"

--############################
--  "EMG"."SUBUE_TBL"  
--############################
create table "SUBUE_TBL"
(
    "MAC" VARCHAR(18) fixed not null,
    "LTEID" VARCHAR(32) fixed not null,
    "SLICE_ID" SMALLINT default 0,
    "DEV_DESC" VARCHAR(48) fixed,
    "AUTH_METHOD" SMALLINT default 0,
    "USERNAME" VARCHAR(24) fixed,
    "SUSPEND" SMALLINT default 0,
    "IP_POOL_INDEX" INTEGER not null,
    "IP_ADDR" VARCHAR(48) fixed not null,
    "NETMASK" VARCHAR(48) fixed,
    "CREATE_TIME" DATE default SYSDATE,
    "UPDATE_TIME" DATE,
    "NAS_MDN" VARCHAR(48) fixed,
    "NAS_IP" VARCHAR(48) fixed,
    "DNS_IP" VARCHAR(48) fixed,
    "SESS_START_DATE" DATE,
    "SESS_UPDATE_DATE" DATE,
    "SESS_STOP_DATE" DATE,
    "ACCT_SESS_ID" VARCHAR(128) variable,
    "NAS_PORT_TYPE" SMALLINT,
    "IN_OCTETS" BIGINT default 0,
    "IN_GIGAWORDS" SMALLINT default 0,
    "OUT_OCTETS" BIGINT default 0,
    "OUT_GIGAWORDS" SMALLINT default 0,
    "LAST_TERM_CAUSE" VARCHAR(32) fixed,
    "QOS_MBR" INTEGER default 0,
    "QOS_GBR" INTEGER default 0,
    "QOS_DSCP" SMALLINT default 0,
    "LAST_IN_OCTETS" BIGINT default 0,
    "LAST_OUT_OCTETS" BIGINT default 0,
    "LAST_IN_GIGAWORDS" SMALLINT default 0,
    "LAST_OUT_GIGAWORDS" SMALLINT default 0
)
 tablespace "SYS_TBS_MEM_DATA";

connect "EMG" / "emg123"

--############################
--  "EMG"."TOKEN_TBL"  
--############################
create table "TOKEN_TBL"
(
    "LTEID" VARCHAR(32) fixed not null,
    "MDN" VARCHAR(16) fixed not null,
    "AUTH_INFO" VARCHAR(128) variable,
    "ACCESS_TOKEN_TYPE" VARCHAR(16) fixed,
    "ACCESS_TOKEN" VARCHAR(128) variable,
    "REFRESH_TOKEN" VARCHAR(128) variable,
    "ACCESS_TOKEN_EXPIRE" BIGINT,
    "REFRESH_TOKEN_EXPIRE" BIGINT,
    "ACCESS_TOKEN_EXPIRE_DATE" DATE
)
 tablespace "SYS_TBS_MEM_DATA";
