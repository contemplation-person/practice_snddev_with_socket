connect "EMG" / "emg123"
alter table "ACCOUNT_TBL" add constraint "ACCUNT_PK" primary key("LTEID","USERNAME") using 
index tablespace "SYS_TBS_MEM_DATA";

alter table "ACL_TBL" add constraint "ACL_PK" primary key("NAS_MDN","SUBUE_MAC") using 
index tablespace "SYS_TBS_MEM_DATA";

create index "ACL_IDX" on "ACL_TBL"("NAS_MDN") tablespace "SYS_TBS_MEM_DATA";

alter table "NAS_HIST_TBL" add constraint "NAS_HIST_PK" primary key("MDN","ON_DATE") using 
index tablespace "HIST_TBS";

alter table "NAS_TBL" add constraint "NAS_PK" primary key("MDN") using 
index tablespace "SYS_TBS_MEM_DATA";

create index "NAS_IDX" on "NAS_TBL"("LTEID") tablespace "SYS_TBS_MEM_DATA";

alter table "SOCINFO_TBL" add constraint "SOCINFO_PK" primary key("LTEID") using 
index tablespace "SYS_TBS_MEM_DATA";

alter table "SUBUE_HIST_TBL" add constraint "SUBUE_HIST_PK" primary key("MAC","SESS_START_DATE") using 
index tablespace "SYS_TBS_MEM_DATA";

alter table "SUBUE_IP6POOL_TBL" add constraint "IP6POOL_PK" primary key("LTEID","IP_POOL_INDEX") using 
index tablespace "SYS_TBS_MEM_DATA";

create index "SUBUE_IP6POOL_IDX" on "SUBUE_IP6POOL_TBL"("LTEID") tablespace "SYS_TBS_MEM_DATA";

alter table "SUBUE_IP6_TBL" add constraint "SUBUE_IP6_PK" primary key("LTEID","IP_ADDR") using 
index tablespace "SYS_TBS_MEM_DATA";

create index "SUBUE_IP6_IDX" on "SUBUE_IP6_TBL"("MAC") tablespace "SYS_TBS_MEM_DATA";

alter table "SUBUE_IPPOOL_TBL" add constraint "IPPOOL_PK" primary key("LTEID","IP_POOL_INDEX") using 
index tablespace "SYS_TBS_MEM_DATA";

create index "SUBUE_IPPOOL_IDX" on "SUBUE_IPPOOL_TBL"("LTEID") tablespace "SYS_TBS_MEM_DATA";

alter table "SUBUE_IP_TBL" add constraint "SUBUE_IP_PK" primary key("LTEID","IP_ADDR") using 
index tablespace "SYS_TBS_MEM_DATA";

create index "SUBUE_IP_IDX" on "SUBUE_IP_TBL"("MAC") tablespace "SYS_TBS_MEM_DATA";

alter table "SUBUE_TBL" add constraint "SUBUE_PK" primary key("MAC") using 
index tablespace "SYS_TBS_MEM_DATA";

create index "SUBUE_IDX" on "SUBUE_TBL"("LTEID") tablespace "SYS_TBS_MEM_DATA";

create index "SUBUE_IDX2" on "SUBUE_TBL"("NAS_MDN") tablespace "SYS_TBS_MEM_DATA";

alter table "TOKEN_TBL" add constraint "TOKEN_PK" primary key("MDN") using 
index tablespace "SYS_TBS_MEM_DATA";

