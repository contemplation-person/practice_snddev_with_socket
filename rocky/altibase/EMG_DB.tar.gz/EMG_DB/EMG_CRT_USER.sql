--############################
--  USER 
--############################
create user "EMG" identified by "emg123"
 temporary tablespace "SYS_TBS_DISK_TEMP"
 default tablespace "SYS_TBS_MEM_DATA"
 access "HIST_TBS" on;

