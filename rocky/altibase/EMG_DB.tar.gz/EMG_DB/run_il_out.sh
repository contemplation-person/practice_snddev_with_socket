iloader -s 127.0.0.1 -u EMG -p emg123 formout -f EMG_ACCOUNT_TBL.fmt -T ACCOUNT_TBL -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 out -f EMG_ACCOUNT_TBL.fmt -d EMG_ACCOUNT_TBL.dat -log EMG_ACCOUNT_TBL.log -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 formout -f EMG_ACL_TBL.fmt -T ACL_TBL -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 out -f EMG_ACL_TBL.fmt -d EMG_ACL_TBL.dat -log EMG_ACL_TBL.log -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 formout -f EMG_NAS_HIST_TBL.fmt -T NAS_HIST_TBL -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 out -f EMG_NAS_HIST_TBL.fmt -d EMG_NAS_HIST_TBL.dat -log EMG_NAS_HIST_TBL.log -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 formout -f EMG_NAS_TBL.fmt -T NAS_TBL -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 out -f EMG_NAS_TBL.fmt -d EMG_NAS_TBL.dat -log EMG_NAS_TBL.log -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 formout -f EMG_SOCINFO_TBL.fmt -T SOCINFO_TBL -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 out -f EMG_SOCINFO_TBL.fmt -d EMG_SOCINFO_TBL.dat -log EMG_SOCINFO_TBL.log -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 formout -f EMG_SUBUE_HIST_TBL.fmt -T SUBUE_HIST_TBL -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 out -f EMG_SUBUE_HIST_TBL.fmt -d EMG_SUBUE_HIST_TBL.dat -log EMG_SUBUE_HIST_TBL.log -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 formout -f EMG_SUBUE_IP6POOL_TBL.fmt -T SUBUE_IP6POOL_TBL -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 out -f EMG_SUBUE_IP6POOL_TBL.fmt -d EMG_SUBUE_IP6POOL_TBL.dat -log EMG_SUBUE_IP6POOL_TBL.log -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 formout -f EMG_SUBUE_IP6_TBL.fmt -T SUBUE_IP6_TBL -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 out -f EMG_SUBUE_IP6_TBL.fmt -d EMG_SUBUE_IP6_TBL.dat -log EMG_SUBUE_IP6_TBL.log -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 formout -f EMG_SUBUE_IPPOOL_TBL.fmt -T SUBUE_IPPOOL_TBL -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 out -f EMG_SUBUE_IPPOOL_TBL.fmt -d EMG_SUBUE_IPPOOL_TBL.dat -log EMG_SUBUE_IPPOOL_TBL.log -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 formout -f EMG_SUBUE_IP_TBL.fmt -T SUBUE_IP_TBL -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 out -f EMG_SUBUE_IP_TBL.fmt -d EMG_SUBUE_IP_TBL.dat -log EMG_SUBUE_IP_TBL.log -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 formout -f EMG_SUBUE_TBL.fmt -T SUBUE_TBL -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 out -f EMG_SUBUE_TBL.fmt -d EMG_SUBUE_TBL.dat -log EMG_SUBUE_TBL.log -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 formout -f EMG_TOKEN_TBL.fmt -T TOKEN_TBL -NLS_USE MS949
iloader -s 127.0.0.1 -u EMG -p emg123 out -f EMG_TOKEN_TBL.fmt -d EMG_TOKEN_TBL.dat -log EMG_TOKEN_TBL.log -NLS_USE MS949
