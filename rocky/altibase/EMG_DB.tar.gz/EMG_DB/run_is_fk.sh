isql -s 127.0.0.1 -u EMG -p emg123 -f EMG_CRT_FK.sql
isql -s 127.0.0.1 -u EMG -p emg123 -f EMG_CRT_TRIG.sql
